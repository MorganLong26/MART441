# Assignment 5
This week we had to create the beginning of the memory card game. I wanted to go with the theme of sharks. I chose five different pictures of sharks and for the back of the cards I chose your stereo typical backing for a deck of cards. This week we also implemented arrays and cookies. I have had experience with arrays in Creative Coding 1, but I have never dealt with cookies before.

## Issues
This week I mostly followed all of the video tutorials on the course website and had a few minor issues. I was able to get all 10 cards to show up and have the ability to flip and show a picture underneath. The issue I ran into was that only two of my five images were popping up under all 10 cards. When I emailed our professor about my issue I found out that it was because my var count for my images was set to only two zeros instead of five, and my count random number was set to five instead of two.  
